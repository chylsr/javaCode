package homework.k2;

public class Res {
    int id;
    Ss res;

    public Res(int id, Ss res) {
        this.id = id;
        this.res = res;
    }
}
