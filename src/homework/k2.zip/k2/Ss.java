package homework.k2;

abstract class Ss {
    int a;
    int b;
}
